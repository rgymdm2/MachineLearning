import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.imageio.ImageIO;

/**
 * Calculates the cost with multi-threading.
 *
 * @author rgymdm2
 *
 */
class calcThread extends Thread {
    private Thread t;
    private String threadName;

    public int i = 0;
    public double cost = 0;

    calcThread(String name, int num) {
        this.threadName = name;
        this.i = num;
        System.out.print("");
    }

    public double getCosts() {
        return this.cost;
    }

    @Override
    public void run() {
        try {
            double c = MLMain.runAndReturnCost(this.i);
            this.cost += c;
            System.out.print("");
        } catch (IOException e) {
            System.out.println(
                    "Thread " + this.threadName + " has an IO exception.");
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void start() {
        if (this.t == null) {
            this.t = new Thread(this, this.threadName);
            this.t.start();
        }
    }
}

public final class MLMain {

    //number of neurons
    static int n = 8;

    static int samples = 200;
    static int start = 0;

    static int resX = 30, resY = 30;

    //strength of connections
    static double[][] neurons1 = new double[n][resX * resY]; //!!!!!!!!!! ONLY RECORDS RED
    static double[][] neurons2 = new double[n][n];
    static double[][] neurons3 = new double[2][n];

    //actual data
    static double[][] neurons1_data = new double[800][n];//samples
    static double[][] neurons2_data = new double[800][n];
    static double[][] neurons3_data = new double[800][2];

    static double[] bias1 = new double[n];
    static double[] bias2 = new double[n];
    static double[] bias3 = new double[2];

    //if there is saved data
    static boolean hasSavedData = false;

    static double[][] values1D = new double[samples][100 * 100];
    static int[] number = new int[samples];

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private MLMain() {
    }

    private static double sigmoid(double x) {
        return 1 / (1 + Math.exp(-x));
    }

    public static void randomize(double[] values) {
        for (int i = 0; i < values.length; i++) {
            values[i] = Math.random() * 5;
            if (Math.random() < 0.5) {
                values[i] *= -1;
            }
        }
    }

    public static double calc(double[] input, double[] neurons, double bias) {
        double data = 0;
        //for each neuron connection
        for (int i = 0; i < neurons.length; i++) {
            //for each input
            for (int i2 = 0; i2 < input.length; i2++) {
                //add value for each input
                data += input[i2] * neurons[i] + bias;
            }
        }
        return data;
    }

    //adjust every number to 0-1
    private static void adjust(double[] x) {
        double min = x[0];

        for (double i : x) {
            if (i < min) {
                min = i;
            }
        }

        for (int i = 0; i < x.length; i++) {
            x[i] -= min;
        }

        double max = x[0];

        for (double i : x) {
            if (i > max) {
                max = i;
            }
        }

        for (int i = 0; i < x.length; i++) {
            x[i] /= max;
        }

    }

    //specifically for layer 3
    private static void adjust2(double[] x) {
        if (x[0] >= x[1]) {
            x[0] = sigmoid(x[0] / x[1]);
            x[1] = 0;
        } else {
            x[1] = sigmoid(x[1] / x[0]);
            x[0] = 0;
        }

    }

    public static double calcCost(double[] input, double[] expected) {
        double result = 0;
        for (int i = 0; i < input.length; i++) {
            result += (input[i] - expected[i]) * (input[i] - expected[i]);
        }
        return result;
    }

    private static boolean runTest(int i) throws IOException {

        File file = new File("data\\" + i + ".txt");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String input = br.readLine();

        int number = Integer.parseInt(input);

        BufferedImage image = ImageIO.read(new File("data\\" + i + ".png"));

        double[] values1D = new double[image.getWidth() * image.getHeight()];

        //read image
        int k = 0;
        for (int x = 0; x < image.getWidth(); x++) {
            for (int y = 0; y < image.getHeight(); y++) {
                Color c = new Color(image.getRGB(x, y), true);

                //save data to 1D array
                values1D[k] = c.getRed();
                k += 1;
            }
        }

        //calculate neuron group 1
        for (int i2 = 0; i2 < n; i2++) {
            neurons1_data[i][i2] = calc(values1D, neurons1[i2], bias1[i2]);
        }

        adjust(neurons1_data[i]);

        //calculate neuron group 2
        for (int i2 = 0; i2 < n; i2++) {
            neurons2_data[i][i2] = calc(neurons1_data[i], neurons2[i2],
                    bias2[i2]);
        }

        adjust(neurons2_data[i]);

        //calculate results
        for (int i2 = 0; i2 < 2; i2++) {
            neurons3_data[i][i2] = calc(neurons2_data[i], neurons3[i2],
                    bias3[i2]);
        }

        adjust2(neurons3_data[i]);

        System.out.println("result: 0 = " + neurons3_data[i][0] + " 1 = "
                + neurons3_data[i][1] + ", correct result is " + number);

        br.close();

        //return if the result is correct
        if ((number == 0 && neurons3_data[i][0] > neurons3_data[i][1])
                || (number == 1 && neurons3_data[i][1] > neurons3_data[i][0])) {
            return true;
        } else {
            return false;
        }
    }

    public static double runAndReturnCost(int i) throws IOException {

        File file = new File("data\\" + i + ".txt");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String input = br.readLine();

        int number = Integer.parseInt(input);

        BufferedImage image = ImageIO.read(new File("data\\" + i + ".png"));

        double[] values1D = new double[image.getWidth() * image.getHeight()];

        //read image
        int k = 0;
        for (int x = 0; x < image.getWidth(); x++) {
            for (int y = 0; y < image.getHeight(); y++) {
                Color c = new Color(image.getRGB(x, y), true);

                //save data to 1D array
                values1D[k] = c.getRed();
                k += 1;
            }
        }

        //calculate neuron group 1
        for (int i2 = 0; i2 < n; i2++) {
            neurons1_data[i][i2] = calc(values1D, neurons1[i2], bias1[i2]);
        }

        adjust(neurons1_data[i]);

        //calculate neuron group 2
        for (int i2 = 0; i2 < n; i2++) {
            neurons2_data[i][i2] = calc(neurons1_data[i], neurons2[i2],
                    bias2[i2]);
        }

        adjust(neurons2_data[i]);

        //calculate results
        for (int i2 = 0; i2 < 2; i2++) {
            neurons3_data[i][i2] = calc(neurons2_data[i], neurons3[i2],
                    bias3[i2]);
        }

        adjust2(neurons3_data[i]);

        double[] expected;
        if (number == 0) {
            expected = new double[] { 1, 0 };
        } else {
            expected = new double[] { 0, 1 };
        }

        double cost = calcCost(neurons3_data[i], expected);

        br.close();
        return cost;
    }

    private static double getAllCosts() throws IOException { //!!!!!!
        double cost = 0;

        Thread[] t = new Thread[samples];
        calcThread[] ct = new calcThread[samples];

        for (int i = start; i < samples; i++) {
            ct[i] = new calcThread("cost #" + i, i);
        }

        for (int i = start; i < samples; i++) {
            t[i] = new Thread(ct[i]);
            t[i].start();
        }

        try {
            for (int i = start; i < samples; i++) {
                t[i].join();
                cost += ct[i].getCosts();
            }
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted error. " + e.getMessage());
        }

        return cost;
    }

    public static void optimizeN1(double[][] neuron, int x, int y)
            throws IOException {

        double lowestCost = getAllCosts();

        boolean run = true;
        boolean left = false, right = false;

        //try reducing the value
        neuron[x][y] -= 0.1;

        if (getAllCosts() - lowestCost < 0) {
            //reducing the value works
            left = true;
            neuron[x][y] += 0.1;
        } else {
            //reducing the value doesn't work
            //try increasing the value
            left = false;
            neuron[x][y] += 0.2;
            if (getAllCosts() - lowestCost < 0) {
                //increasing the value works
                right = true;
            } else {
                right = false;
            }
            neuron[x][y] -= 0.1;
        }

        if (!left && !right) {
            run = false;
        }

        System.out.println("499 Current cost: " + getAllCosts() + " x, y = " + x
                + " " + y);

        while (run && neuron[x][y] >= -5 && neuron[x][y] <= 5) {
            lowestCost = getAllCosts();
            //move left/right until can't move anymore
            if (left && neuron[x][y] >= -4.9) {
                neuron[x][y] -= 0.1;
            }

            if (right && neuron[x][y] <= 4.9) {
                neuron[x][y] += 0.1;
            }

            System.out.println(
                    "Current cost: " + getAllCosts() + "x, y = " + x + " " + y);
            run = getAllCosts() < lowestCost;
        }
    }

    private static void optimize(double[] neuron, int x) throws IOException {

        double lowestCost = getAllCosts();
        double oldCost = lowestCost;
        System.out.println("lowest cost is " + lowestCost);

        boolean run = true;
        boolean left = false, right = false;

        //try reducing the value
        neuron[x] -= 0.1;

        if (getAllCosts() - lowestCost < 0) {

            System.out.println("moving left works");

            //reducing the value works
            left = true;
            neuron[x] += 0.1;
        } else {
            System.out.println("moving left doesn't work");
            //reducing the value doesn't work
            //try increasing the value
            left = false;
            neuron[x] += 0.2;
            if (getAllCosts() - lowestCost < 0) {
                //increasing the value works
                right = true;
                System.out.println("moving right works");
            } else {
                right = false;
                System.out.println("moving right doesn't work");
            }
            neuron[x] -= 0.1;
        }

        if (!left && !right) {
            run = false;
        }

        while (run && neuron[x] >= -5 && neuron[x] <= 5
                && getAllCosts() <= oldCost) {
            lowestCost = getAllCosts();
            //move left/right until can't move anymore
            if (left && neuron[x] >= -4.9) {
                neuron[x] -= 0.1;
                System.out.println(
                        "moving left. Value = " + neuron[x] + ". x = " + x);
            }

            if (right && neuron[x] <= 4.9) {
                neuron[x] += 0.1;
                System.out.println(
                        "moving right. Value = " + neuron[x] + ". x = " + x);
            }

            double c = getAllCosts();
            run = c < lowestCost && neuron[x] >= -5 && neuron[x] <= 5
                    && c < oldCost;
            System.out.println("Current cost: " + c + " old cost: " + oldCost
                    + "run = " + run);

            if (!run) {
                if (left) {
                    neuron[x] += 0.1;
                } else {
                    neuron[x] -= 0.1;
                }
                System.out.println("run = false. reverting last change. "
                        + (getAllCosts() < lowestCost) + " " + neuron[x]);
                System.out.println("cost now is " + getAllCosts());
            }
        }
    }

    private static void optimize(double[][] neuron, int x, int y)
            throws IOException {

        double lowestCost = getAllCosts();
        double oldCost = lowestCost;
        System.out.println("lowest cost is " + lowestCost);

        boolean run = true;
        boolean left = false, right = false;

        //try reducing the value
        neuron[x][y] -= 0.1;

        if (getAllCosts() - lowestCost < 0) {

            System.out.println("moving left works");

            //reducing the value works
            left = true;
            neuron[x][y] += 0.1;
        } else {
            System.out.println("moving left doesn't work");
            //reducing the value doesn't work
            //try increasing the value
            left = false;
            neuron[x][y] += 0.2;
            if (getAllCosts() - lowestCost < 0) {
                //increasing the value works
                right = true;
                System.out.println("moving right works");
            } else {
                right = false;
                System.out.println("moving right doesn't work");
            }
            neuron[x][y] -= 0.1;
        }

        if (!left && !right) {
            run = false;
        }

        while (run && neuron[x][y] >= -5 && neuron[x][y] <= 5
                && getAllCosts() <= oldCost) {
            lowestCost = getAllCosts();
            //move left/right until can't move anymore
            if (left && neuron[x][y] >= -4.9) {
                neuron[x][y] -= 0.1;
                System.out.println("moving left. Value = " + neuron[x][y]
                        + ". x, y = " + x + " " + y);
            }

            if (right && neuron[x][y] <= 4.9) {
                neuron[x][y] += 0.1;
                System.out.println("moving right. Value = " + neuron[x][y]
                        + ". x, y = " + x + " " + y);
            }

            double c = getAllCosts();
            run = c < lowestCost && neuron[x][y] >= -5 && neuron[x][y] <= 5
                    && c < oldCost;
            System.out.println("561 Current cost: " + c + " old cost: "
                    + oldCost + "run = " + run);

            if (!run) {
                if (left) {
                    neuron[x][y] += 0.1;
                } else {
                    neuron[x][y] -= 0.1;
                }
                System.out.println("run = false. reverting last change. "
                        + (getAllCosts() < lowestCost) + " " + neuron[x][y]);
                System.out.println("cost now is " + getAllCosts());
            }
        }
    }

    public static void readFromSaveFile() throws FileNotFoundException {
        Scanner n1 = new Scanner(new File("data\\neurons1.txt"));
        for (int i = 0; i < n; i++) {
            for (int i2 = 0; i2 < 30 * 30; i2++) {
                neurons1[i][i2] = n1.nextDouble();
            }
        }

        Scanner n2 = new Scanner(new File("data\\neurons2.txt"));
        for (int i = 0; i < n; i++) {
            for (int i2 = 0; i2 < n; i2++) {
                neurons2[i][i2] = n2.nextDouble();
            }
        }

        Scanner n3 = new Scanner(new File("data\\neurons3.txt"));
        for (int i = 0; i < 2; i++) {
            for (int i2 = 0; i2 < n; i2++) {
                neurons3[i][i2] = n3.nextDouble();
            }
        }

        Scanner b1 = new Scanner(new File("data\\bias1.txt"));
        for (int i = 0; i < n; i++) {
            bias1[i] = b1.nextDouble();
        }

        Scanner b2 = new Scanner(new File("data\\bias2.txt"));
        for (int i = 0; i < n; i++) {
            bias2[i] = b2.nextDouble();
        }

        Scanner b3 = new Scanner(new File("data\\bias3.txt"));
        for (int i = 0; i < 2; i++) {
            bias3[i] = b3.nextDouble();
        }
    }

    public static void saveToFile() throws IOException {
        FileWriter n1 = new FileWriter("data\\neurons1.txt", false);

        for (int i = 0; i < n; i++) {
            for (int i2 = 0; i2 < resX * resY; i2++) {
                n1.write("" + neurons1[i][i2] + "\n");
            }
        }
        n1.close();
        System.out.println("neurons1 saved.");

        FileWriter n2 = new FileWriter("data\\neurons2.txt", false);
        for (int i = 0; i < n; i++) {
            for (int i2 = 0; i2 < n; i2++) {
                n2.write("" + neurons2[i][i2] + "\n");
            }
        }
        n2.close();
        System.out.println("neurons2 saved.");

        FileWriter n3 = new FileWriter("data\\neurons3.txt", false);
        for (int i = 0; i < 2; i++) {
            for (int i2 = 0; i2 < n; i2++) {
                n3.write("" + neurons3[i][i2] + "\n");
            }
        }
        n3.close();
        System.out.println("neurons3 saved.");

        FileWriter b1 = new FileWriter("data\\bias1.txt", false);
        for (int i = 0; i < n; i++) {
            b1.write("" + bias1[i] + "\n");
        }
        b1.close();
        System.out.println("bias1 saved.");

        FileWriter b2 = new FileWriter("data\\bias2.txt", false);
        for (int i = 0; i < n; i++) {
            b2.write("" + bias2[i] + "\n");
        }
        b2.close();
        System.out.println("bias2 saved.");

        FileWriter b3 = new FileWriter("data\\bias3.txt", false);
        for (int i = 0; i < 2; i++) {
            b3.write("" + bias3[i] + "\n");
        }
        b3.close();
        System.out.println("bias3 saved.");
    }

    public static void main(String[] args) throws IOException {
        System.out.println("Load from save file? y/n");

        Scanner in = new Scanner(System.in);

        String read = in.nextLine();

        if (read.charAt(0) == 'y') {
            System.out.println("reading from save file");
            readFromSaveFile();
            System.out.println("save file loaded");
        } else {

            for (int i = 0; i < neurons1.length; i++) {
                randomize(neurons1[i]);
            }

            for (int i = 0; i < neurons2.length; i++) {
                randomize(neurons2[i]);
            }

            for (int i = 0; i < neurons3.length; i++) {
                randomize(neurons3[i]);
            }

            randomize(bias1);
            randomize(bias2);
            randomize(bias3);

            System.out.println("all neurons randomized.");
        }

        System.out.println("test current network? y/n");
        read = in.nextLine();

        if (read.equals("y")) {
            //test network
            int c = 0;
            for (int i = 200; i < 400; i++) {
                if (runTest(i) == true) {
                    c++;
                }
                System.out.println("amount of correct results: " + c);
            }
        } else {
            int runs = 0;
            while (getAllCosts() >= 120) {
                runs++;
                samples = 200;
                start = 0;
                double originalCost = getAllCosts();

                for (start = 0; start <= 199 - 24; start += 24) {
                    samples = start + 24;
                    for (int x = 0; x < n; x++) {
                        System.out.println("optimizing " + x
                                + "for bias 1, training sample #" + start);
                        optimize(bias1, x);
                    }

                    for (int x = 0; x < n; x++) {
                        System.out.println("optimizing " + x
                                + "for bias 2, training sample #" + start);
                        optimize(bias2, x);
                    }

                    for (int x = 0; x < 2; x++) {
                        System.out.println("optimizing " + x
                                + "for bias 3, training sample #" + start);
                        optimize(bias3, x);
                    }

                    for (int x = 0; x < n; x++) {
                        for (int y = 0; y < resX * resY; y++) {
                            System.out.println("optimizing " + x + " , " + y
                                    + "for n1, training sample #" + start);
                            optimizeN1(neurons1, x, y);
                        }
                    }

                    for (int x = 0; x < n; x++) {
                        for (int y = 0; y < n; y++) {
                            System.out.println("optimizing " + x + " , " + y
                                    + "for n2, training sample #" + start);
                            optimize(neurons2, x, y);
                        }
                    }

                    for (int x = 0; x < 2; x++) {
                        for (int y = 0; y < n; y++) {
                            System.out.println("optimizing " + x + " , " + y
                                    + "for n3, training sample #" + start);
                            optimize(neurons3, x, y);
                        }
                    }
                }

                System.out.println();

                samples = 200;
                start = 0;

                double c = getAllCosts();
                System.out.println("training complete. cost = " + c
                        + "and original cost = " + originalCost);

                System.out.println();

                //write to log file
                File file = new File("data\\record.txt");
                BufferedWriter br = new BufferedWriter(new FileWriter(file));

                br.write("\ntraining complete. cost = " + c
                        + "and original cost = " + originalCost + "\n\n");
                br.write("runs: " + runs);

                br.close();
            }
            System.out.println("save training data? y/n");
            read = in.nextLine();

            if (read.charAt(0) == 'y') {
                System.out.println("saving to file");
                saveToFile();
            }
        }
    }
}
