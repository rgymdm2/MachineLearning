import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

/**
 * Randomly generates a number of triangles and rectangles, then saves them to a
 * folder, along with a .txt document that records their shape.
 *
 * @author rgymdm2
 *
 */
public final class Shapes {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Shapes() {
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {

        Random rand = new Random();

        //Squares are labeled as 0's
        for (int i = 0; i < 400; i += 2) {
            BufferedImage image = new BufferedImage(30, 30,
                    BufferedImage.TYPE_INT_ARGB);

            int x = rand.nextInt(21);
            int y = rand.nextInt(21);
            int w = rand.nextInt(25 - x) + 5;
            int h = rand.nextInt(25 - y) + 5;

            Graphics2D g = image.createGraphics();

            g.setColor(Color.white);
            g.fillRect(0, 0, 30, 30);

            g.setColor(Color.black);
            g.fillRect(x, y, w, h);
            try {
                BufferedWriter writer = new BufferedWriter(
                        new FileWriter("data\\" + i + ".txt"));
                writer.write("0");
                writer.close();

                File outputfile = new File("data\\" + i + ".png");
                outputfile.createNewFile();
                if (ImageIO.write(image, "png", outputfile) == false) {
                    System.out.println("no printer found");
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                System.out.println("File err.");
                e.printStackTrace();
            }
            System.out.println(
                    "Created image : x1 = " + x + " y1 = " + y + " x2 = "
                            + (x + w) + " y2 = " + (y + h) + " number = " + i);
        }

        //Triangles are labeled as 1's
        for (int i = 1; i < 400; i += 2) {
            BufferedImage image = new BufferedImage(30, 30,
                    BufferedImage.TYPE_INT_ARGB);

            int[] x = new int[3];
            x[0] = rand.nextInt(6) + 12;
            int w = rand.nextInt(9) + 3;
            x[1] = x[0] + w;
            x[2] = x[0] - w;
            int[] y = new int[3];
            y[0] = rand.nextInt(10) + 3;
            y[1] = y[0] + rand.nextInt(14) + 3;
            y[2] = y[1];

            Graphics2D g = image.createGraphics();

            g.setColor(Color.white);
            g.fillRect(0, 0, 30, 30);

            g.setColor(Color.black);
            g.fillPolygon(x, y, 3);
            try {
                BufferedWriter writer = new BufferedWriter(
                        new FileWriter("data\\" + i + ".txt"));
                writer.write("1");
                writer.close();

                File outputfile = new File("data\\" + i + ".png");
                outputfile.createNewFile();
                if (ImageIO.write(image, "png", outputfile) == false) {
                    System.out.println("no printer found");
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                System.out.println("File err.");
                e.printStackTrace();
            }
        }

    }

}
